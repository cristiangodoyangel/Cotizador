from django.apps import AppConfig


class CotizacionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cotizacion"
